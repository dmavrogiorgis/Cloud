<!DOCTYPE html>
<html>
<head>
    <title> Unauthorized - Movies & Cinemas </title>
    <link rel="stylesheet" href="style_keyrock.css" />
</head>
<body class="unauthorized_div">
    <div class="row">
        <a name="unauthorized" class="unauthorized btn" href=welcome.php> Go To Sign In Form</a>
    </div>

</body>
</html> 
