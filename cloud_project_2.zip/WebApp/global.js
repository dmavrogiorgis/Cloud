// global.js
//var docker_or_gcp_ip = "http://172.18.1.8/"; // DOCKER IP
var docker_or_gcp_ip = "http://34.65.222.5:81/";    // GCP_IP